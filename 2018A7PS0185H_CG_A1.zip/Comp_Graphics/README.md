# Comp_Graphics
The repository containing the solution of Assignment - 1 of course IS F311



Made by :

1. Param Bhatt 2018A8PS0862H
2. Siddhant Kulkarni  2018A7PS0185H
3. Sravani Garapati  2018A7PS0097H
