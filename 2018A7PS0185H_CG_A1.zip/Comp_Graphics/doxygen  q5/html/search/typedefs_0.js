var searchData=
[
  ['extreme',['extreme',['../tree_8h.html#aca506b23b36c98c5e97eed4d29e79900',1,'tree.h']]]
];
