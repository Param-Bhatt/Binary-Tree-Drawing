var searchData=
[
  ['center_5fx',['center_x',['../classcircle.html#acb3d4e48483b2ea9837fa75cc0977c0d',1,'circle']]],
  ['center_5fy',['center_y',['../classcircle.html#ae297efc5c3c3b7a2e6595ed74e324c88',1,'circle']]]
];
