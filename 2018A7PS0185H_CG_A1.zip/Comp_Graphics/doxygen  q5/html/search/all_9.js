var searchData=
[
  ['node',['node',['../structnode.html',1,'node'],['../tree_8h.html#af4aeda155dbe167f1c1cf38cb65bf324',1,'node():&#160;tree.h']]]
];
