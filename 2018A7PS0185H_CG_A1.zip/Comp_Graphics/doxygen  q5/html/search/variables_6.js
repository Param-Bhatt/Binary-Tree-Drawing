var searchData=
[
  ['parent',['parent',['../structnode.html#a05e4fe9e0177ba2d8dbd2c487cfddd53',1,'node']]]
];
