var searchData=
[
  ['sx',['sx',['../classline.html#a75af55c0f7d0f1f113d12fd6e1d53ed0',1,'line']]],
  ['sy',['sy',['../classline.html#afd9ace37f8fe42bf6438208f6acfae74',1,'line']]]
];
